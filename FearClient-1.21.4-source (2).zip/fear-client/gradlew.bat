@echo off
setlocal EnableExtensions
rem Minimal Windows Gradle bootstrap for environments without gradle-wrapper.jar.
rem Uses the official Gradle distribution and caches it in the user's Gradle directory.
set "GRADLE_VERSION=8.12.1"
set "BOOTSTRAP_DIR=%USERPROFILE%\.gradle\fear-bootstrap"
set "GRADLE_HOME=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME%\bin\gradle.bat"
set "GRADLE_ZIP=%BOOTSTRAP_DIR%\gradle-%GRADLE_VERSION%-bin.zip"

if exist "%GRADLE_EXE%" goto run_gradle
if not exist "%BOOTSTRAP_DIR%" mkdir "%BOOTSTRAP_DIR%"
if errorlevel 1 goto fail_dir

echo [Fear] Gradle %GRADLE_VERSION% not found; downloading official Gradle distribution...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'"
if errorlevel 1 goto fail_download

echo [Fear] Extracting Gradle...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%GRADLE_ZIP%' -DestinationPath '%BOOTSTRAP_DIR%' -Force"
if errorlevel 1 goto fail_extract
if not exist "%GRADLE_EXE%" goto fail_exe

:run_gradle
call "%GRADLE_EXE%" %*
exit /b %errorlevel%

:fail_dir
echo [Fear] ERROR: Could not create Gradle bootstrap directory.
exit /b 1
:fail_download
echo [Fear] ERROR: Gradle download failed. Check internet access and try again.
exit /b 1
:fail_extract
echo [Fear] ERROR: Could not extract Gradle distribution.
exit /b 1
:fail_exe
echo [Fear] ERROR: Gradle executable was not found after extraction.
exit /b 1
