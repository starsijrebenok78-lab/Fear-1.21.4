@echo off
setlocal
call "%~dp0gradlew.bat" build
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Copy the first meaningful Gradle error and share it for diagnosis.
  exit /b 1
)
echo.
echo Build successful. Look for the remapped mod JAR in build\libs\.
exit /b 0
