package ru.fear.client;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class ChinaHatRenderer {
    private static final int RIM_RED = 255;
    private static final int RIM_GREEN = 91;
    private static final int RIM_BLUE = 158;
    private static final int SPOKE_RED = 255;
    private static final int SPOKE_GREEN = 166;
    private static final int SPOKE_BLUE = 203;
    private static final int ALPHA = 235;
    private static final int SEGMENTS = 48;

    private ChinaHatRenderer() {}

    public static void render(WorldRenderContext context) {
        if (!FearClient.chinaHatEnabled || context.world() == null) return;

        MatrixStack matrices = context.matrixStack();
        VertexConsumerProvider consumers = context.consumers();
        if (matrices == null || consumers == null) return;

        Vec3d camera = context.camera().getPos();
        VertexConsumer lines = consumers.getBuffer(RenderLayer.getLines());

        for (PlayerEntity player : context.world().getPlayers()) {
            if (player.isSpectator()) continue;
            Vec3d pos = player.getLerpedPos(1.0F);
            matrices.push();
            matrices.translate(pos.x - camera.x, pos.y - camera.y + player.getHeight() + 0.08, pos.z - camera.z);
            MatrixStack.Entry entry = matrices.peek();

            float radius = 0.72F;
            float coneHeight = 0.48F;
            float apexX = 0.0F;
            float apexY = coneHeight;
            float apexZ = 0.0F;

            for (int i = 0; i < SEGMENTS; i++) {
                double a0 = (Math.PI * 2.0 * i) / SEGMENTS;
                double a1 = (Math.PI * 2.0 * (i + 1)) / SEGMENTS;
                float x0 = (float) (Math.cos(a0) * radius);
                float z0 = (float) (Math.sin(a0) * radius);
                float x1 = (float) (Math.cos(a1) * radius);
                float z1 = (float) (Math.sin(a1) * radius);

                line(lines, entry, x0, 0.0F, z0, x1, 0.0F, z1,
                        RIM_RED, RIM_GREEN, RIM_BLUE, ALPHA);

                if (i % 4 == 0) {
                    line(lines, entry, x0, 0.0F, z0, apexX, apexY, apexZ,
                            SPOKE_RED, SPOKE_GREEN, SPOKE_BLUE, ALPHA);
                }
            }
            matrices.pop();
        }
    }

    private static void line(VertexConsumer consumer, MatrixStack.Entry matrix,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             int red, int green, int blue, int alpha) {
        consumer.vertex(matrix, x1, y1, z1)
                .color(red, green, blue, alpha)
                .normal(matrix, 0.0F, 1.0F, 0.0F);
        consumer.vertex(matrix, x2, y2, z2)
                .color(red, green, blue, alpha)
                .normal(matrix, 0.0F, 1.0F, 0.0F);
    }
}
