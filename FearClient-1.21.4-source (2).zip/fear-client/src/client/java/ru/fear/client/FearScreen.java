package ru.fear.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class FearScreen extends Screen {
    private static final int PANEL_WIDTH = 570;
    private static final int PANEL_HEIGHT = 330;

    private int panelX;
    private int panelY;
    private int panelW;
    private int panelH;

    public FearScreen() {
        super(Text.literal("Fear Client"));
    }

    @Override
    protected void init() {
        panelW = Math.min(PANEL_WIDTH, Math.max(360, width - 20));
        panelH = Math.min(PANEL_HEIGHT, Math.max(250, height - 20));
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xAA030611);

        // Window and sidebar
        context.fill(panelX + 5, panelY + 6, panelX + panelW + 5, panelY + panelH + 6, 0x55000000);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF10B1020);
        context.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFFFF5D9E);
        context.fill(panelX, panelY + 3, panelX + 145, panelY + panelH, 0xFF10182A);
        context.fill(panelX + 144, panelY + 3, panelX + 145, panelY + panelH, 0xFF263047);

        // Branding
        context.drawTextWithShadow(textRenderer, Text.literal("FEAR"), panelX + 22, panelY + 22, 0xFFFF6FA8);
        context.drawTextWithShadow(textRenderer, Text.literal("VISUAL CLIENT"), panelX + 22, panelY + 39, 0xFF9BA8C2);
        context.fill(panelX + 17, panelY + 59, panelX + 128, panelY + 60, 0xFF29334A);

        drawSidebarItem(context, "OVERVIEW", panelX + 19, panelY + 80, false);
        drawSidebarItem(context, "VISUALS", panelX + 19, panelY + 109, true);
        drawSidebarItem(context, "HUD", panelX + 19, panelY + 138, false);
        drawSidebarItem(context, "SETTINGS", panelX + 19, panelY + 167, false);

        context.drawTextWithShadow(textRenderer, Text.literal("FEAR / VISUALS"), panelX + 169, panelY + 23, 0xFFF2F5FB);
        context.drawTextWithShadow(textRenderer, Text.literal("Client-side cosmetics and interface"), panelX + 169, panelY + 41, 0xFF8C9AB4);

        int cardY = panelY + 78;
        int cardW = 176;
        int cardH = 105;
        int firstX = panelX + 166;
        int secondX = panelX + panelW - cardW - 22;
        drawModuleCard(context, firstX, cardY, cardW, cardH,
                "China Hat", "Cosmetic cone above players", FearClient.chinaHatEnabled, mouseX, mouseY);
        drawModuleCard(context, secondX, cardY, cardW, cardH,
                "Custom HUD", "Fear tag and coordinates", FearClient.hudEnabled, mouseX, mouseY);

        context.fill(panelX + 166, panelY + 205, panelX + panelW - 22, panelY + 206, 0xFF273149);
        context.drawTextWithShadow(textRenderer, Text.literal("MENU KEY"), panelX + 168, panelY + 220, 0xFF8C9AB4);
        context.fill(panelX + panelW - 90, panelY + 214, panelX + panelW - 22, panelY + 238, 0xFF1A263B);
        context.drawTextWithShadow(textRenderer, Text.literal("RSHIFT"), panelX + panelW - 76, panelY + 222, 0xFFFF80B4);

        context.drawTextWithShadow(textRenderer, Text.literal("VISUAL ONLY  •  LOCAL CLIENT"), panelX + 166, panelY + panelH - 25, 0xFF687895);
        context.drawTextWithShadow(textRenderer, Text.literal("×"), panelX + panelW - 24, panelY + 12, 0xFFE9EDF5);
    }

    private void drawSidebarItem(DrawContext context, String label, int x, int y, boolean active) {
        if (active) {
            context.fill(x - 5, y - 5, panelX + 132, y + 17, 0xFF202A40);
            context.fill(x - 5, y - 5, x - 2, y + 17, 0xFFFF5D9E);
        }
        context.drawTextWithShadow(textRenderer, Text.literal(label), x, y, active ? 0xFFFFD9E8 : 0xFF8794AD);
    }

    private void drawModuleCard(DrawContext context, int x, int y, int w, int h,
                                String title, String description, boolean enabled,
                                int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        context.fill(x, y, x + w, y + h, hovered ? 0xFF1C2940 : 0xFF151F32);
        context.fill(x, y, x + w, y + 1, enabled ? 0xFFFF5D9E : 0xFF344057);
        context.drawTextWithShadow(textRenderer, Text.literal(title), x + 12, y + 14, 0xFFF2F5FB);
        context.drawTextWithShadow(textRenderer, Text.literal(description), x + 12, y + 33, 0xFF91A0B8);

        int toggleX = x + 12;
        int toggleY = y + h - 29;
        int toggleW = 56;
        int toggleColor = enabled ? 0xFF8D3565 : 0xFF303B50;
        context.fill(toggleX, toggleY, toggleX + toggleW, toggleY + 18, toggleColor);
        context.drawTextWithShadow(textRenderer, Text.literal(enabled ? "ON" : "OFF"), toggleX + 17, toggleY + 5,
                enabled ? 0xFFFFF2F8 : 0xFFB2BED0);
        context.drawTextWithShadow(textRenderer, Text.literal(enabled ? "ENABLED" : "DISABLED"), x + 79, toggleY + 5,
                enabled ? 0xFFFF9BC2 : 0xFF74829A);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);
        if (mouseX >= panelX + panelW - 36 && mouseY >= panelY + 5 && mouseY <= panelY + 35) {
            close();
            return true;
        }

        int cardY = panelY + 78;
        int cardW = 176;
        int cardH = 105;
        int firstX = panelX + 166;
        int secondX = panelX + panelW - cardW - 22;
        if (inside(mouseX, mouseY, firstX, cardY, cardW, cardH)) {
            FearClient.chinaHatEnabled = !FearClient.chinaHatEnabled;
            return true;
        }
        if (inside(mouseX, mouseY, secondX, cardY, cardW, cardH)) {
            FearClient.hudEnabled = !FearClient.hudEnabled;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
