package ru.fear.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public final class FearClient implements ClientModInitializer {
    public static boolean chinaHatEnabled = true;
    public static boolean hudEnabled = true;

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.fear.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.fear.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen instanceof FearScreen) {
                    client.setScreen(null);
                } else {
                    client.setScreen(new FearScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register(FearClient::renderHud);
        WorldRenderEvents.AFTER_ENTITIES.register(ChinaHatRenderer::render);
    }

    private static void renderHud(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!hudEnabled || client.player == null || client.world == null || client.options.hudHidden) {
            return;
        }

        int x = 8;
        int y = 8;
        int width = 205;
        int height = 47;
        context.fill(x + 2, y + 2, x + width + 2, y + height + 2, 0x65000000);
        context.fill(x, y, x + width, y + height, 0xE90B1020);
        context.fill(x, y, x + 3, y + height, 0xFFFF5D9E);
        context.drawTextWithShadow(client.textRenderer, Text.literal("FEAR"), x + 11, y + 7, 0xFFFF70AA);
        context.drawTextWithShadow(client.textRenderer, Text.literal("VISUAL CLIENT  /  1.21.4"), x + 48, y + 7, 0xFFE6EAF2);

        String coordinates = String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f",
                client.player.getX(), client.player.getY(), client.player.getZ());
        context.drawTextWithShadow(client.textRenderer, Text.literal(coordinates), x + 11, y + 27, 0xFFBFC8DA);
    }
}
